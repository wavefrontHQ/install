Wavefront Collectd Python Installer
